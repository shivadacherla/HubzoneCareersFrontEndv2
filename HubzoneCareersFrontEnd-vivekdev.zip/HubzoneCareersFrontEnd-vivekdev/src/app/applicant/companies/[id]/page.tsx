import { CompanyDetailPage } from "@/components/companies/company-detail-page";

export default function CompanyDetail() {
  return <CompanyDetailPage />;
}

