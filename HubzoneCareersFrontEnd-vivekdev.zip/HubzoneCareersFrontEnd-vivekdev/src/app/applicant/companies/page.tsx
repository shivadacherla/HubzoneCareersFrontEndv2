import { CompaniesListPage } from "@/components/companies/companies-list-page";

export default function ApplicantCompanies() {
  return <CompaniesListPage />;
}
