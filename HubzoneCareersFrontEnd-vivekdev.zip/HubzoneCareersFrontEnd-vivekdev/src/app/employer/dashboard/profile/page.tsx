import { EmployerProfilePage } from "@/components/employer-dashboard/employer-profile-page";

export default function EmployerProfileDashboardPage() {
  return <EmployerProfilePage />;
}

