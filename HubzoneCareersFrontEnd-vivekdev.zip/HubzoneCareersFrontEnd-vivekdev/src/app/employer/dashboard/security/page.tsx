import { EmployerSecurityPage } from "@/components/employer-dashboard/employer-security-page";

export default function EmployerSecurityDashboardPage() {
  return <EmployerSecurityPage />;
}

