import { ApplicantSearchPage } from "@/components/employer-dashboard/applicant-search-page";

export default function ApplicantSearchDashboardPage() {
  return <ApplicantSearchPage />;
}

