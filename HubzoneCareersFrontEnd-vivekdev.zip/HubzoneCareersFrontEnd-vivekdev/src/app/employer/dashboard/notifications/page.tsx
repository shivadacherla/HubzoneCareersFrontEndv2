import { EmployerNotificationsPage } from "@/components/employer-dashboard/employer-notifications-page";

export default function EmployerNotificationsDashboardPage() {
  return <EmployerNotificationsPage />;
}

