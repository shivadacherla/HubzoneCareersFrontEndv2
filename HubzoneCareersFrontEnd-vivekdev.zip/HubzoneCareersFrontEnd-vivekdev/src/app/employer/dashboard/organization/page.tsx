import { OrganizationPage } from "@/components/employer-dashboard/organization-page";

export default function OrganizationDashboardPage() {
  return <OrganizationPage />;
}

