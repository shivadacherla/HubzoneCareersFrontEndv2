import { JobPostingForm } from "@/components/employer-dashboard/job-posting-form";

export default function NewJobPage() {
  return <JobPostingForm />;
}

