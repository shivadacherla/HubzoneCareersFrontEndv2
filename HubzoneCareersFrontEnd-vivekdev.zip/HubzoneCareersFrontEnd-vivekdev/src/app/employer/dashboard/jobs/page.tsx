import { JobsListPage } from "@/components/employer-dashboard/jobs-list-page";

export default function JobsDashboardPage() {
  return <JobsListPage />;
}

