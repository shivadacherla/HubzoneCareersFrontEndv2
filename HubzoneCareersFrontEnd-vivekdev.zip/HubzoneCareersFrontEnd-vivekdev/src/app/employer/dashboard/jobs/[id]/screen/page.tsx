import { ResumeScreeningPage } from "@/components/employer-dashboard/resume-screening-page";

export default function ResumeScreeningDashboardPage() {
  return <ResumeScreeningPage />;
}

