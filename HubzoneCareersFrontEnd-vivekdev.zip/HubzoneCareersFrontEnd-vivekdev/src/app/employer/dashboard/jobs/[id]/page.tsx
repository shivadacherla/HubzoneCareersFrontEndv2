import { JobDetailPage } from "@/components/employer-dashboard/job-detail-page";

export default function JobDetailDashboardPage() {
  return <JobDetailPage />;
}

