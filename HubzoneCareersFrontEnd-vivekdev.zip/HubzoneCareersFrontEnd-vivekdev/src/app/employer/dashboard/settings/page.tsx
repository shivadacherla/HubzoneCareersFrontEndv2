import { EmployerSettingsPage } from "@/components/employer-dashboard/employer-settings-page";

export default function EmployerSettingsDashboardPage() {
  return <EmployerSettingsPage />;
}

