import { EmployerDashboardHome } from "@/components/employer-dashboard/employer-dashboard-home";

export default function EmployerDashboardPage() {
  return <EmployerDashboardHome />;
}

