import { TeamManagementPage } from "@/components/employer-dashboard/team-management-page";

export default function TeamManagementDashboardPage() {
  return <TeamManagementPage />;
}

